-- 08_functions_and_dates.sql
-- Topics: COALESCE, string functions, date functions, CASE, type casting (SQLite syntax)

-- Q1. Replace missing accuracy with 0 for reporting.
SELECT request_id, COALESCE(accuracy, 0) AS accuracy_filled FROM requests;

-- Q2. Upper-case country and first 3 letters as a short code.
SELECT name, UPPER(country) AS country_upper, UPPER(SUBSTR(country, 1, 3)) AS short_code
FROM users;

-- Q3. Build a label like 'Aarav (India)'.
SELECT name || ' (' || country || ')' AS label FROM users;

-- Q4. Year and month parts of the request date.
SELECT request_id,
       strftime('%Y', request_date) AS year,
       strftime('%m', request_date) AS month,
       strftime('%w', request_date) AS weekday_number   -- 0 = Sunday
FROM requests;

-- Q5. How many days since each user signed up when they made their first request?
SELECT u.name,
       CAST(julianday(MIN(r.request_date)) - julianday(u.signup_date) AS INTEGER) AS days_to_first_request
FROM users u
JOIN requests r ON r.user_id = u.user_id
GROUP BY u.user_id, u.name;

-- Q6. Label each language as 'priority' if low-resource and average accuracy is under 0.80.
SELECT l.language_name,
       ROUND(AVG(r.accuracy), 3) AS avg_accuracy,
       CASE WHEN l.resource_level = 'low' AND AVG(r.accuracy) < 0.80 THEN 'priority'
            ELSE 'ok' END AS flag
FROM languages l
JOIN requests r ON r.language_code = l.language_code
WHERE r.accuracy BETWEEN 0 AND 1
GROUP BY l.language_code, l.language_name, l.resource_level;
