-- 07_data_quality_checks.sql
-- Topics: the "data hygiene" work a data analyst does before trusting any dashboard.
-- Each check should return ZERO rows on clean data. Here the dataset is deliberately messy.

-- Q1. Count missing values per column.
SELECT SUM(CASE WHEN accuracy      IS NULL THEN 1 ELSE 0 END) AS missing_accuracy,
       SUM(CASE WHEN latency_ms    IS NULL THEN 1 ELSE 0 END) AS missing_latency,
       SUM(CASE WHEN language_code IS NULL THEN 1 ELSE 0 END) AS missing_language
FROM requests;

-- Q2. Find duplicate requests (same user, language, service, date, accuracy).
SELECT user_id, language_code, service, request_date, accuracy, COUNT(*) AS copies
FROM requests
GROUP BY user_id, language_code, service, request_date, accuracy
HAVING COUNT(*) > 1;

-- Q3. Out-of-range values: accuracy must be between 0 and 1.
SELECT request_id, accuracy FROM requests WHERE accuracy < 0 OR accuracy > 1;

-- Q4. Orphan records: requests pointing to a user or language that does not exist.
SELECT r.request_id
FROM requests r
LEFT JOIN users u     ON r.user_id = u.user_id
LEFT JOIN languages l ON r.language_code = l.language_code
WHERE u.user_id IS NULL OR l.language_code IS NULL;

-- Q5. Failed requests that have no accuracy score (expected) vs successful ones missing it (a problem).
SELECT status, COUNT(*) AS rows_missing_accuracy
FROM requests
WHERE accuracy IS NULL
GROUP BY status;

-- Q6. Successful requests with zero or impossible latency.
SELECT request_id, latency_ms FROM requests WHERE status = 'success' AND latency_ms <= 0;

-- Q7. Failed requests that have no error logged (gaps in logging).
SELECT r.request_id
FROM requests r
LEFT JOIN errors e ON r.request_id = e.request_id
WHERE r.status = 'failed' AND e.error_id IS NULL;

-- Q8. Delete the duplicate, keeping the lowest request_id of each group.
-- (Run this on a COPY of the table first. Shown here as a SELECT preview.)
SELECT request_id
FROM requests
WHERE request_id NOT IN (
    SELECT MIN(request_id)
    FROM requests
    GROUP BY user_id, language_code, service, request_date, accuracy
);
-- DELETE FROM requests WHERE request_id IN ( ...the query above... );
