-- 01_select_and_filter.sql
-- Topics: SELECT, WHERE, AND/OR, IN, BETWEEN, LIKE, IS NULL, DISTINCT, ORDER BY, LIMIT

-- Q1. Show all users from India.
SELECT * FROM users WHERE country = 'India';

-- Q2. List the distinct services offered.
SELECT DISTINCT service FROM requests;

-- Q3. Requests in Hindi or Bengali with accuracy below 0.85.
SELECT request_id, language_code, service, accuracy
FROM requests
WHERE language_code IN ('hi', 'bn') AND accuracy < 0.85;

-- Q4. Requests made in February 2026.
SELECT request_id, request_date, language_code
FROM requests
WHERE request_date BETWEEN '2026-02-01' AND '2026-02-28';

-- Q5. Users whose name starts with 'S' or ends with 'a'.
SELECT name FROM users WHERE name LIKE 'S%' OR name LIKE '%a';

-- Q6. Requests where accuracy is missing.
SELECT request_id, status FROM requests WHERE accuracy IS NULL;

-- Q7. The 5 slowest requests (highest latency).
SELECT request_id, language_code, latency_ms
FROM requests
ORDER BY latency_ms DESC
LIMIT 5;
