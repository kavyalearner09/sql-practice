-- 02_aggregation_group_by.sql
-- Topics: COUNT, SUM, AVG, MIN, MAX, GROUP BY, HAVING, CASE WHEN, monthly trends

-- Q1. Total number of requests.
SELECT COUNT(*) AS total_requests FROM requests;

-- Q2. Requests per language.
SELECT language_code, COUNT(*) AS total_requests
FROM requests
GROUP BY language_code
ORDER BY total_requests DESC;

-- Q3. Average accuracy and latency per service.
SELECT service,
       ROUND(AVG(accuracy), 3)   AS avg_accuracy,
       ROUND(AVG(latency_ms), 0) AS avg_latency
FROM requests
GROUP BY service;

-- Q4. Languages whose average accuracy is below 0.85 (HAVING filters groups).
SELECT language_code, ROUND(AVG(accuracy), 3) AS avg_accuracy
FROM requests
GROUP BY language_code
HAVING AVG(accuracy) < 0.85;

-- Q5. Requests per month (usage trend).
SELECT strftime('%Y-%m', request_date) AS month, COUNT(*) AS total_requests
FROM requests
GROUP BY month
ORDER BY month;

-- Q6. Failure rate (%) per service.
SELECT service,
       ROUND(100.0 * SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) / COUNT(*), 1) AS failure_rate_pct
FROM requests
GROUP BY service;

-- Q7. Bucket requests into accuracy bands and count each.
SELECT CASE
           WHEN accuracy >= 0.90 THEN 'high'
           WHEN accuracy >= 0.80 THEN 'medium'
           ELSE 'low'
       END AS accuracy_band,
       COUNT(*) AS total
FROM requests
WHERE accuracy IS NOT NULL
GROUP BY accuracy_band;
