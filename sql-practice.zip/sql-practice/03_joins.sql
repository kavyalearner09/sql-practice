-- 03_joins.sql
-- Topics: INNER JOIN, LEFT JOIN, anti-join, multi-table joins, self join

-- Q1. Each request with the user's name and country (INNER JOIN).
SELECT r.request_id, u.name, u.country, r.language_code
FROM requests r
JOIN users u ON r.user_id = u.user_id;

-- Q2. Requests with the full language name instead of the code.
SELECT r.request_id, l.language_name, r.service, r.accuracy
FROM requests r
JOIN languages l ON r.language_code = l.language_code;

-- Q3. All users and how many requests each made, including users with zero (LEFT JOIN).
SELECT u.name, COUNT(r.request_id) AS total_requests
FROM users u
LEFT JOIN requests r ON u.user_id = r.user_id
GROUP BY u.user_id, u.name
ORDER BY total_requests DESC;

-- Q4. Users who never made a request (anti-join: LEFT JOIN + IS NULL).
SELECT u.name
FROM users u
LEFT JOIN requests r ON u.user_id = r.user_id
WHERE r.request_id IS NULL;

-- Q5. Languages that have no requests at all.
SELECT l.language_name
FROM languages l
LEFT JOIN requests r ON l.language_code = r.language_code
WHERE r.request_id IS NULL;

-- Q6. Error counts by language name (joining three tables).
SELECT l.language_name, e.error_type, COUNT(*) AS total_errors
FROM errors e
JOIN requests r  ON e.request_id = r.request_id
JOIN languages l ON r.language_code = l.language_code
GROUP BY l.language_name, e.error_type
ORDER BY total_errors DESC;

-- Q7. Average accuracy for low-resource vs high-resource languages.
SELECT l.resource_level, ROUND(AVG(r.accuracy), 3) AS avg_accuracy
FROM requests r
JOIN languages l ON r.language_code = l.language_code
WHERE r.accuracy BETWEEN 0 AND 1
GROUP BY l.resource_level;

-- Q8. Pairs of users from the same country (self join).
SELECT a.name AS user_1, b.name AS user_2, a.country
FROM users a
JOIN users b ON a.country = b.country AND a.user_id < b.user_id;
