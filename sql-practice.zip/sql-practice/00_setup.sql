-- 00_setup.sql
-- Creates a small "language services" database (usage, accuracy, errors)
-- so every practice query in this repo can be run and checked.
-- Run:  sqlite3 practice.db < 00_setup.sql

DROP TABLE IF EXISTS errors;
DROP TABLE IF EXISTS requests;
DROP TABLE IF EXISTS languages;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    user_id     INTEGER PRIMARY KEY,
    name        TEXT,
    country     TEXT,
    signup_date TEXT
);

CREATE TABLE languages (
    language_code  TEXT PRIMARY KEY,
    language_name  TEXT,
    resource_level TEXT            -- 'high' or 'low' (how much training data exists)
);

CREATE TABLE requests (
    request_id    INTEGER PRIMARY KEY,
    user_id       INTEGER,
    language_code TEXT,
    service       TEXT,            -- translation / speech_to_text
    request_date  TEXT,
    accuracy      REAL,            -- model accuracy score, should be 0 to 1
    latency_ms    INTEGER,
    status        TEXT,            -- success / failed
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (language_code) REFERENCES languages(language_code)
);

CREATE TABLE errors (
    error_id   INTEGER PRIMARY KEY,
    request_id INTEGER,
    error_type TEXT,               -- noise / accent / wrong_word / timeout
    FOREIGN KEY (request_id) REFERENCES requests(request_id)
);

INSERT INTO users VALUES
(1,'Aarav','India','2025-01-10'),
(2,'Meera','India','2025-02-14'),
(3,'Lars','Sweden','2025-03-01'),
(4,'Sofia','Spain','2025-03-20'),
(5,'John','USA','2025-04-05'),
(6,'Priya','India','2025-05-11'),
(7,'Elena','Germany','2025-06-02'),
(8,'Omar','UAE','2025-06-18'),
(9,'Chen','China','2025-07-09'),
(10,'Tara','India','2025-08-01');

INSERT INTO languages VALUES
('hi','Hindi','low'),
('bn','Bengali','low'),
('ta','Tamil','low'),
('te','Telugu','low'),
('ar','Arabic','low'),
('sv','Swedish','high'),
('es','Spanish','high'),
('de','German','high');

INSERT INTO requests VALUES
(1,1,'hi','translation','2026-01-05',0.91,420,'success'),
(2,1,'hi','speech_to_text','2026-01-06',0.84,900,'success'),
(3,2,'bn','translation','2026-01-07',0.78,510,'success'),
(4,2,'bn','translation','2026-01-12',0.81,480,'success'),
(5,3,'sv','translation','2026-01-15',0.96,300,'success'),
(6,3,'sv','speech_to_text','2026-01-20',0.93,760,'success'),
(7,4,'es','translation','2026-01-22',0.95,320,'success'),
(8,4,'es','translation','2026-02-02',0.94,310,'success'),
(9,5,'es','speech_to_text','2026-02-03',0.90,820,'success'),
(10,5,'de','translation','2026-02-05',0.95,350,'success'),
(11,6,'hi','translation','2026-02-09',0.88,430,'success'),
(12,6,'ta','translation','2026-02-11',0.72,600,'success'),
(13,6,'ta','speech_to_text','2026-02-14',0.69,1100,'success'),
(14,7,'de','translation','2026-02-18',0.96,330,'success'),
(15,7,'de','speech_to_text','2026-02-25',NULL,870,'failed'),
(16,8,'ar','translation','2026-03-01',0.80,540,'success'),
(17,8,'ar','speech_to_text','2026-03-03',0.74,1000,'success'),
(18,9,'hi','translation','2026-03-05',0.89,410,'success'),
(19,9,'bn','speech_to_text','2026-03-10',0.70,1050,'success'),
(20,1,'hi','translation','2026-03-12',0.92,400,'success'),
(21,2,'bn','translation','2026-03-15',0.76,530,'success'),
(22,3,'sv','translation','2026-03-18',0.97,290,'success'),
(23,5,'es','translation','2026-03-20',0.93,315,'success'),
(24,6,'ta','translation','2026-03-22',0.73,610,'success'),
(25,8,'ar','translation','2026-03-25',0.82,520,'success'),
(26,9,'hi','speech_to_text','2026-03-28',NULL,0,'failed'),
(27,4,'es','speech_to_text','2026-03-30',0.91,800,'success'),
(28,7,'de','translation','2026-04-02',0.95,340,'success'),
(29,2,'bn','speech_to_text','2026-04-04',0.71,1080,'success'),
(30,1,'hi','translation','2026-04-06',0.90,415,'success'),
(31,1,'hi','translation','2026-04-06',0.90,415,'success'),   -- deliberate duplicate of 30
(32,5,'de','translation','2026-04-08',1.70,360,'success');   -- deliberate bad value (accuracy > 1)

INSERT INTO errors VALUES
(1,2,'noise'),
(2,3,'wrong_word'),
(3,12,'wrong_word'),
(4,13,'noise'),
(5,13,'accent'),
(6,15,'timeout'),
(7,17,'accent'),
(8,19,'accent'),
(9,19,'noise'),
(10,26,'timeout'),
(11,29,'accent'),
(12,21,'wrong_word');
