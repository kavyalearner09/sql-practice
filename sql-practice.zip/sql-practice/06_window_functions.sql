-- 06_window_functions.sql
-- Topics: ROW_NUMBER, RANK, DENSE_RANK, LAG/LEAD, running total, moving average, NTILE, PARTITION BY

-- Q1. Rank all requests by accuracy (RANK leaves gaps on ties, DENSE_RANK does not).
SELECT request_id, language_code, accuracy,
       RANK()       OVER (ORDER BY accuracy DESC) AS rnk,
       DENSE_RANK() OVER (ORDER BY accuracy DESC) AS dense_rnk
FROM requests
WHERE accuracy BETWEEN 0 AND 1;

-- Q2. The most recent request for each user (ROW_NUMBER + PARTITION BY).
SELECT * FROM (
    SELECT request_id, user_id, request_date,
           ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY request_date DESC) AS rn
    FROM requests
)
WHERE rn = 1;

-- Q3. Top 2 most accurate requests in each language.
SELECT * FROM (
    SELECT request_id, language_code, accuracy,
           ROW_NUMBER() OVER (PARTITION BY language_code ORDER BY accuracy DESC) AS rn
    FROM requests
    WHERE accuracy BETWEEN 0 AND 1
)
WHERE rn <= 2;

-- Q4. Running total of requests by date.
SELECT request_date,
       COUNT(*) AS daily_requests,
       SUM(COUNT(*)) OVER (ORDER BY request_date) AS running_total
FROM requests
GROUP BY request_date;

-- Q5. Compare each request's accuracy with the average for its language.
SELECT request_id, language_code, accuracy,
       ROUND(AVG(accuracy) OVER (PARTITION BY language_code), 3) AS lang_avg,
       ROUND(accuracy - AVG(accuracy) OVER (PARTITION BY language_code), 3) AS diff_from_lang_avg
FROM requests
WHERE accuracy BETWEEN 0 AND 1;

-- Q6. Days since each user's previous request (LAG).
SELECT user_id, request_date,
       LAG(request_date) OVER (PARTITION BY user_id ORDER BY request_date) AS prev_request,
       julianday(request_date)
         - julianday(LAG(request_date) OVER (PARTITION BY user_id ORDER BY request_date)) AS days_gap
FROM requests;

-- Q7. 3-request moving average of latency.
SELECT request_id, request_date, latency_ms,
       ROUND(AVG(latency_ms) OVER (ORDER BY request_date, request_id
                                   ROWS BETWEEN 2 PRECEDING AND CURRENT ROW), 1) AS moving_avg_3
FROM requests;

-- Q8. Split requests into 4 equal groups by latency (NTILE).
SELECT request_id, latency_ms,
       NTILE(4) OVER (ORDER BY latency_ms) AS latency_quartile
FROM requests;
