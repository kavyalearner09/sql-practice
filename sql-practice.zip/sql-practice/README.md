# SQL Practice

SQL queries I practiced and organized by topic, using a small **language services** database
(users, languages, translation / speech-to-text requests, accuracy scores, and error logs).

I picked this dataset because it mirrors the kind of analysis done on real platforms:
usage trends, model accuracy by language, error analysis, and data quality checks.

## How to run

```bash
sqlite3 practice.db < 00_setup.sql                 # create the database + sample data
sqlite3 -header -column practice.db < 03_joins.sql # run any topic file
```

(No SQLite? Use https://sqliteonline.com and paste in `00_setup.sql` first.)

## Tables

| Table | What it holds |
|---|---|
| `users` | user_id, name, country, signup_date |
| `languages` | language_code, language_name, resource_level (high / low) |
| `requests` | one row per API request: language, service, date, accuracy, latency, status |
| `errors` | error_type (noise, accent, wrong_word, timeout) linked to a request |

## Topics covered

| File | Topic | Queries |
|---|---|---|
| `01_select_and_filter.sql` | SELECT, WHERE, IN, BETWEEN, LIKE, NULL, ORDER BY, LIMIT | 7 |
| `02_aggregation_group_by.sql` | COUNT / AVG / SUM, GROUP BY, HAVING, CASE, monthly trends | 7 |
| `03_joins.sql` | INNER, LEFT, anti-join, multi-table, self join | 8 |
| `04_subqueries.sql` | scalar, IN / NOT IN, EXISTS, correlated, derived tables | 7 |
| `05_cte.sql` | WITH clauses, chained CTEs | 4 |
| `06_window_functions.sql` | ROW_NUMBER, RANK, LAG, running total, moving average, NTILE | 8 |
| `07_data_quality_checks.sql` | nulls, duplicates, out-of-range values, orphans, logging gaps | 8 |
| `08_functions_and_dates.sql` | COALESCE, string and date functions, CASE | 6 |

## Also practiced on

- HackerRank (SQL track)
- SQLBolt (all lessons)

*(Add your profile links here.)*
