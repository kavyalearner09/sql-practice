-- 04_subqueries.sql
-- Topics: scalar subquery, IN, NOT IN, EXISTS, correlated subquery, derived table

-- Q1. Requests with accuracy above the overall average (scalar subquery).
SELECT request_id, language_code, accuracy
FROM requests
WHERE accuracy > (SELECT AVG(accuracy) FROM requests WHERE accuracy BETWEEN 0 AND 1);

-- Q2. Users who made at least one speech_to_text request (IN).
SELECT name
FROM users
WHERE user_id IN (SELECT user_id FROM requests WHERE service = 'speech_to_text');

-- Q3. Users who never made a request (NOT IN).
SELECT name
FROM users
WHERE user_id NOT IN (SELECT user_id FROM requests);

-- Q4. Requests that have at least one logged error (EXISTS).
SELECT r.request_id, r.language_code
FROM requests r
WHERE EXISTS (SELECT 1 FROM errors e WHERE e.request_id = r.request_id);

-- Q5. Each request that is slower than the average for its own language (correlated subquery).
SELECT r.request_id, r.language_code, r.latency_ms
FROM requests r
WHERE r.latency_ms > (SELECT AVG(r2.latency_ms)
                      FROM requests r2
                      WHERE r2.language_code = r.language_code);

-- Q6. The language with the highest average accuracy (derived table).
SELECT language_code, avg_accuracy
FROM (
    SELECT language_code, AVG(accuracy) AS avg_accuracy
    FROM requests
    WHERE accuracy BETWEEN 0 AND 1
    GROUP BY language_code
)
ORDER BY avg_accuracy DESC
LIMIT 1;

-- Q7. Second highest latency value (classic interview question).
SELECT MAX(latency_ms) AS second_highest_latency
FROM requests
WHERE latency_ms < (SELECT MAX(latency_ms) FROM requests);
