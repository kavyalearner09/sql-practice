-- 05_cte.sql
-- Topics: WITH (CTE), multiple CTEs, building a query step by step

-- Q1. Languages whose average accuracy is below the overall average.
WITH lang_acc AS (
    SELECT language_code, AVG(accuracy) AS avg_accuracy
    FROM requests
    WHERE accuracy BETWEEN 0 AND 1
    GROUP BY language_code
)
SELECT language_code, ROUND(avg_accuracy, 3) AS avg_accuracy
FROM lang_acc
WHERE avg_accuracy < (SELECT AVG(avg_accuracy) FROM lang_acc);

-- Q2. Monthly requests and the month-over-month change (two CTE steps).
WITH monthly AS (
    SELECT strftime('%Y-%m', request_date) AS month, COUNT(*) AS total
    FROM requests
    GROUP BY month
)
SELECT month,
       total,
       total - LAG(total) OVER (ORDER BY month) AS change_vs_prev_month
FROM monthly;

-- Q3. Users with more than 3 requests, with their average accuracy.
WITH busy_users AS (
    SELECT user_id, COUNT(*) AS total_requests
    FROM requests
    GROUP BY user_id
    HAVING COUNT(*) > 3
)
SELECT u.name, b.total_requests,
       ROUND((SELECT AVG(accuracy) FROM requests r
              WHERE r.user_id = u.user_id AND r.accuracy BETWEEN 0 AND 1), 3) AS avg_accuracy
FROM busy_users b
JOIN users u ON u.user_id = b.user_id;

-- Q4. Error rate per language: errors logged / requests made (two CTEs joined).
WITH req AS (
    SELECT language_code, COUNT(*) AS total_requests
    FROM requests
    GROUP BY language_code
),
err AS (
    SELECT r.language_code, COUNT(*) AS total_errors
    FROM errors e
    JOIN requests r ON e.request_id = r.request_id
    GROUP BY r.language_code
)
SELECT req.language_code,
       req.total_requests,
       COALESCE(err.total_errors, 0) AS total_errors,
       ROUND(1.0 * COALESCE(err.total_errors, 0) / req.total_requests, 2) AS errors_per_request
FROM req
LEFT JOIN err ON req.language_code = err.language_code
ORDER BY errors_per_request DESC;
